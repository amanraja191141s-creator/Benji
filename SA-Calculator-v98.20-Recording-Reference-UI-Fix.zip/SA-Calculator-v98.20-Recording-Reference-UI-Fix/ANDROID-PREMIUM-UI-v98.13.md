# SA Calculator v98.13 — complete adaptive UI and Android system-bar repair

## Scope and source baseline
- Based on the supplied v98.12 source ZIP.
- Preserves the existing 18 registered destinations and calculation/provider logic.
- Adds a final, shared responsive design layer rather than replacing screen-specific layouts.

## UI system updates
- Unified spacing, card radius, typography, form-control heights, focus states, result rows and touch targets across registered tool screens.
- Added a compact-phone breakpoint (380px), short-height breakpoint (700px), and medium/large-width behavior (600px+).
- Added the SA brand mark to the app header.
- Preserved light, dark and OLED semantic surfaces and existing user accent palette tokens.
- Standardized currency converter amount controls, cards and rate metadata without rewriting its exchange-rate engine.

## Android system UI and branding
- Generated native MainActivity.java after Capacitor sync.
- Uses WindowCompat edge-to-edge layout and WindowInsetsCompat system-bar/display-cutout insets to pad the native content host, preventing status/navigation bars and notches from obscuring WebView content.
- Sets transparent system bars, dark navy decor background and light system icons; handles Android Q+ contrast enforcement.
- Applies a matching dark splash background and launcher artwork to generated AppTheme launch styles.
- Installs density-specific launcher icons and adaptive icon resources.
- Adds standard 192px and 512px PWA icon assets and separate any/maskable declarations.

## Automated verification
- `node --test tests/*.test.js`: 158 tests passed, 0 failed in this environment.
- `node --check assets/js/app.js`: passed.
- `node --check scripts/patch-android-native.mjs`: passed.
- `node scripts/prepare-android-web.mjs`: passed.
- Native patch exercised by automated fixture test, including namespace-derived MainActivity and status/navigation/display-cutout inset code.
- ZIP integrity checked after packaging.

## Explicitly not claimed
- No APK binary was provided for inspection or device installation.
- This environment has no generated Android Gradle project/SDK, so actual Gradle compilation and physical-device behavior are pending the GitHub Actions run and installation test.
- Live exchange-rate API availability and provider behavior cannot be guaranteed offline; existing currency tests verify deterministic calculations, freshness, cache and fallback rules.
