# SA Calculator v1.94.0-v94 — Screen Design Audit

## Source reviewed
- `index.html`: app shell, calculator, 17 destinations, dialogs, currency picker, history and settings.
- `assets/css/app.css`: 10k+ lines of accumulated visual rules and responsive overrides.
- `assets/js/app.js`: existing interaction and screen routing retained; this release is a visual/layout polish, not a calculator-engine rewrite.

## Changes
- Added one documented final design layer rather than rewriting historical CSS, preserving the existing theme and interaction model.
- Standardized screen spacing, card radii, form control heights, result hierarchy and text wrapping.
- Improved header action hit areas, calculator keypad sizing, memory controls, settings rows, history actions, scientific buttons and currency picker rows.
- Added compact-width, short-height and tablet/desktop adaptive layouts.
- Added safe-area padding, visible focus treatment, reduced-motion and forced-colors handling.
- Preserved LTR math/input regions while improving RTL form/screen alignment.
- Bumped app and service-worker cache version to `1.94.0-v94`.

## Verification
Run `npm test`. The suite includes all existing v1.93.0 regression tests plus `tests/screen-design.test.js`. Automated CSS/source assertions do not replace physical Android/Acode visual QA. Browser screenshot capture was unavailable in the current headless environment; no claim of device-perfect rendering or zero lag is made.

## Remaining manual QA
- Android Acode WebView: 320, 360, 390 and 430 CSS-pixel widths.
- Short-height and landscape layouts.
- Light/dark themes, all eight languages, Arabic/Urdu RTL.
- Large system text, keyboard navigation, screen-reader labels and physical touch accuracy.
