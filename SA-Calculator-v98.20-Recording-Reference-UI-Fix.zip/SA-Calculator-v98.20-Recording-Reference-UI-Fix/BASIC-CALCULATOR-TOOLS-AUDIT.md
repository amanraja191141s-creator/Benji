# SA Calculator v1.94.0-v94 — Basic Calculator, Tools, Settings and History Audit

Audit basis: source ZIP `SA-Calculator-v92-LOCALIZATION-REBUILD-v1.92.9.zip`, inspected and modified for v1.94.0-v94.

## Basic calculator behavior reviewed

- Tokenization and input validation; no `eval`/dynamic JavaScript execution.
- Operator precedence, left-associative multiplication/division and addition/subtraction, right-associative exponentiation, unary signs and grouping.
- Contextual percentage: a bare percentage on the right of `+`/`-` is applied to the accumulated left value; `%` in multiplication/division is a ratio. Calculator percentage semantics vary across products, so this app's policy is explicitly regression-tested rather than described as universal.
- Implicit multiplication, constants, scientific notation, roots, factorial, trig and inverse trig in DEG/RAD modes.
- Live preview/incomplete-expression handling, error preservation, result commit, repeated equals, expression editing, selection/cursor and atomic scientific-notation deletion.
- Significant-digit and expression-length bounds; finite-result checks and safe rejection of malformed expressions.
- Memory MC/MR/M+/M−/MS persistence and state reset on recall.
- History record/restore, cap behavior, protected-entry retention, reuse/edit, copy/share/name/delete and clear-unlocked behavior.

## Confirmed source fixes in v1.94.0-v94

1. `assets/js/app.js` — `evaluateArithmetic`: malformed adjacent numeric tokens (`1..2`, `1.2.3`, `1e2.3`) previously could tokenize into two numbers and be treated as implicit multiplication. Such adjacent numeric tokens now throw `Invalid numeric literal`.
2. `assets/js/app.js` — `evaluateArithmetic`: documented constant adjacency (`pi2`, `2pi2`, `e2`) now normalizes to multiplication when implicit multiplication is enabled. This behavior remains disabled when the user's implicit-multiplication setting is off. Scientific notation (`2e3`, `1e-7`) remains intact.
3. `assets/js/app.js` — `getCalculatorRepeatOperation`: exponent signs after `e/E` are no longer misidentified as a repeatable binary `+`/`-`. Pressing equals repeatedly after `1e-3` no longer incorrectly subtracts 3.
4. `assets/js/app.js` — Memory Recall: clears stale raw result, repeat-operation, scientific continuation and forced-error preview state before replacing the expression.
5. `assets/js/app.js` — `triggerHaptic`: the Settings value `heavy` (visible label “Strong”) now maps to 50 ms; legacy `strong` is retained as an alias. Previously `heavy` fell through to the 30 ms default.
6. `assets/js/app.js` — `convertUnitValue`: temperatures below absolute zero are rejected when converting from Kelvin or into Kelvin.

## Tool and app surfaces inspected

The 17 screens are Standard Calculator, Currency Converter, Unit Converter, Discount, Percent, Sales Tax, Body Metrics (BMI/BMR), Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip, Unit Price and World Time. Settings (12 groups), History, Favorites, Help/Feedback and local persistence were also inspected.

Regression coverage includes representative formula cases for financial/utility tools; loan amortization with zero-rate/grace-period edge coverage; weighted GPA; temperature absolute-zero checks; date validation and leap-day recurring reminders; hex/BigInt conversion; world-time helper validation; currency-provider freshness/pair math/picker interactions; settings persistence/validation/reset; history protected-entry retention and limits; and service-worker/server/release checks.

## Numerical and behavior notes

- The arithmetic core uses JavaScript IEEE-754 `Number`, not arbitrary-precision decimal arithmetic. The display layer suppresses ordinary binary-float noise through bounded formatting, but the internal value is still binary floating point. For regulated financial accounting or exact decimal ledgers, use a decimal arithmetic engine and explicit currency precision.
- Percent behavior is contextual and intentionally differs from calculators that interpret `%` only as division by 100.
- Tool calculators are tested with representative and boundary cases; this does not mathematically prove every possible input combination.
- Currency rates remain public reference-rate observations, not executable bank/card/remittance quotes. Network provider availability is external.

## Verification

- Full automated suite: see `npm test` result in `RELEASE-VERIFICATION.md`.
- JavaScript syntax checks: passed.
- `package.json` and `manifest.webmanifest` JSON parsing: passed.
- Local HTTP server: `/`, `assets/js/app.js` and `assets/css/app.css` returned HTTP 200.
- ZIP integrity: checked after packaging.

## Remaining release gates

- Physical Android/Acode WebView testing across narrow/wide screens, rotation, keyboard/caret editing, vibration/haptics, and offline/online transitions.
- Manual visual review of every tool screen and all Settings/History dialogs on target devices.
- No universal zero-lag or bug-free guarantee is possible from automated tests alone.
